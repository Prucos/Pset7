<form method="POST" action="buy.php">
    <div class="form-group">
        <input class="form-control" type="text" name="query" placeholder="Stock name">
    </div>
    <div class="form-group">
    <input  class="form-control" type="text" name="amount" placeholder="Number of shares">
    </div>
    <button class="btn btn-primary" type="submit">Buy</button>
</form>