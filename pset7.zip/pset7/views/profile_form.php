<form action="profile.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="oldPass" placeholder="Old password" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="newPass" placeholder="New password" type="password"/>
        </div>
        <div class="form-group">
            <button class="btn btn-primary" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Change password
            </button>
        </div>
    </fieldset>
</form>
<div>
    or go to our<a href="index.php">main page</a>
</div>
