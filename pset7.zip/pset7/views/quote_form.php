<form method="POST" action="quote.php">
    <input type="text" name="query" placeholder="search stock">
    <button class="btn btn-primary" type="submit">Search</button>
</form>